# Інформація про лабораторну роботу

Віктор Новіцький
КВ-03

Розробка статичного інтерфейсу Web-додатка https://docs.google.com/document/d/1YEkm1XZZ0xExENQ48h2ZWl_cJ1h2TzbGmZ7ZI-Z05_g/edit?usp=sharing

Розробка функціональності Web-додатка мовою Javascript https://docs.google.com/document/d/1XGvb5ykeaUsUPp5P_VVi_Ao9LVhMfoItx6Aa6KnY86k/edit?usp=sharing

